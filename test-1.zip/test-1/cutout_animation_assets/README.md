# Cutout animation assets

Used by the "Cutout animation" tutorial:

https://docs.godotengine.org/en/latest/tutorials/animation/cutout_animation.html
